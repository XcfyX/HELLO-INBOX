"""Event-driven safety gate; no hardware I/O.

Call with monotonic millisecond timestamps. Expiry is checked on every step.
An integration must also schedule steps/watchdog checks while idle: this class
cannot stop hardware by itself when no step is called.
Unknown events and clock rollback revoke the lease and ARM. Clock rollback
keeps a high-water mark, so recovery needs time >= that mark, RENEW, then ARM.
DISCONNECT and FAULT also revoke the lease. Repeated CONNECT is conservative:
it disarms and revokes the lease. STOP disarms but preserves a valid lease.
"""


class BodyGate:
    MOVEMENTS = frozenset({"FORWARD", "BACKWARD", "LEFT", "RIGHT"})
    EVENTS = MOVEMENTS | frozenset({
        "CONNECT", "DISCONNECT", "RENEW", "ARM", "STOP", "FAULT", "CLEAR_FAULT"
    })

    def __init__(self):
        self.connected = False
        self.armed = False
        self.fault = False
        self.deadline = None
        self._last_ms = None

    def _revoke(self):
        self.armed = False
        self.deadline = None

    def _valid_lease(self, now_ms):
        return self.deadline is not None and now_ms < self.deadline

    def step(self, now_ms: int, event: str) -> str:
        # Fail closed for malformed arguments, beyond the required typed API.
        if type(now_ms) is not int or not isinstance(event, str):
            self._revoke()
            return "STOP"

        rollback = self._last_ms is not None and now_ms < self._last_ms
        if not rollback:
            self._last_ms = now_ms

        # Even at a regressed timestamp, latch safety events. No recovery event
        # may execute until the timestamp reaches the high-water mark.
        if event == "DISCONNECT":
            self.connected = False
            self._revoke()
            return "STOP"
        if event == "FAULT":
            self.fault = True
            self._revoke()
            return "STOP"
        if rollback or event not in self.EVENTS:
            self._revoke()
            return "STOP"

        # Expire BEFORE handling RENEW, preventing renewal from retaining ARM.
        if not self._valid_lease(now_ms):
            self._revoke()

        if event == "CONNECT":
            self.connected = True
            self._revoke()
        elif event == "STOP":
            self.armed = False
        elif event == "CLEAR_FAULT":
            self.fault = False
            self.armed = False
        elif event == "RENEW":
            if self.connected and not self.fault:
                self.deadline = now_ms + 250
        elif event == "ARM":
            self.armed = (
                self.connected and not self.fault and self._valid_lease(now_ms)
            )
        elif (event in self.MOVEMENTS and self.armed and self.connected
              and not self.fault and self._valid_lease(now_ms)):
            return event
        return "STOP"
