import unittest
from bodygate import BodyGate


class BodyGateTests(unittest.TestCase):
    def setUp(self):
        self.g = BodyGate()

    def ready(self, start=0):
        for event in ("CONNECT", "RENEW", "ARM"):
            self.assertEqual(self.g.step(start, event), "STOP")
        self.assertTrue(self.g.armed)

    def test_initial_state(self):
        self.assertFalse(self.g.connected)
        self.assertFalse(self.g.armed)
        self.assertFalse(self.g.fault)
        self.assertIsNone(self.g.deadline)
        self.assertEqual(self.g.step(0, "FORWARD"), "STOP")

    def test_normal_all_directions(self):
        self.ready()
        for t, event in enumerate(("FORWARD", "BACKWARD", "LEFT", "RIGHT"), 1):
            self.assertEqual(self.g.step(t, event), event)

    def test_arm_without_connection(self):
        self.g.step(0, "ARM")
        self.assertFalse(self.g.armed)

    def test_arm_without_lease(self):
        self.g.step(0, "CONNECT")
        self.g.step(1, "ARM")
        self.assertFalse(self.g.armed)

    def test_renew_disconnected(self):
        self.g.step(0, "RENEW")
        self.assertIsNone(self.g.deadline)

    def test_renew_sets_exact_deadline(self):
        self.g.step(100, "CONNECT")
        self.g.step(101, "RENEW")
        self.assertEqual(self.g.deadline, 351)
        self.assertFalse(self.g.armed)

    def test_boundary_249_valid(self):
        self.ready()
        self.assertEqual(self.g.step(249, "FORWARD"), "FORWARD")

    def test_boundary_250_expired(self):
        self.ready()
        self.assertEqual(self.g.step(250, "FORWARD"), "STOP")
        self.assertFalse(self.g.armed)

    def test_arm_at_deadline_fails(self):
        self.g.step(0, "CONNECT")
        self.g.step(0, "RENEW")
        self.g.step(250, "ARM")
        self.assertFalse(self.g.armed)

    def test_expired_renew_requires_rearm(self):
        self.ready()
        self.assertEqual(self.g.step(250, "RENEW"), "STOP")
        self.assertEqual(self.g.deadline, 500)
        self.assertEqual(self.g.step(251, "FORWARD"), "STOP")
        self.g.step(252, "ARM")
        self.assertEqual(self.g.step(253, "FORWARD"), "FORWARD")

    def test_renew_before_expiry_keeps_arm(self):
        self.ready()
        self.assertEqual(self.g.step(249, "RENEW"), "STOP")
        self.assertEqual(self.g.step(250, "RIGHT"), "RIGHT")
        self.assertEqual(self.g.step(499, "RIGHT"), "STOP")

    def test_stop_disarms_immediately(self):
        self.ready()
        self.assertEqual(self.g.step(1, "STOP"), "STOP")
        self.assertFalse(self.g.armed)
        self.assertEqual(self.g.step(2, "FORWARD"), "STOP")
        self.g.step(3, "ARM")
        self.assertEqual(self.g.step(4, "FORWARD"), "FORWARD")

    def test_disconnect_disarms_immediately(self):
        self.ready()
        self.assertEqual(self.g.step(1, "DISCONNECT"), "STOP")
        self.assertFalse(self.g.connected)
        self.assertFalse(self.g.armed)
        self.assertIsNone(self.g.deadline)

    def test_reconnect_requires_renew_and_arm(self):
        self.ready()
        self.g.step(1, "DISCONNECT")
        self.g.step(2, "CONNECT")
        self.g.step(3, "ARM")
        self.assertEqual(self.g.step(4, "LEFT"), "STOP")
        self.g.step(5, "RENEW")
        self.assertEqual(self.g.step(6, "LEFT"), "STOP")
        self.g.step(7, "ARM")
        self.assertEqual(self.g.step(8, "LEFT"), "LEFT")

    def test_repeated_connect_disarms(self):
        self.ready()
        self.g.step(1, "CONNECT")
        self.assertEqual(self.g.step(2, "RIGHT"), "STOP")
        self.assertIsNone(self.g.deadline)

    def test_fault_disarms_immediately(self):
        self.ready()
        self.assertEqual(self.g.step(1, "FAULT"), "STOP")
        self.assertTrue(self.g.fault)
        self.assertFalse(self.g.armed)
        self.assertEqual(self.g.step(2, "BACKWARD"), "STOP")

    def test_renew_and_arm_cannot_bypass_fault(self):
        self.ready()
        self.g.step(1, "FAULT")
        self.g.step(2, "RENEW")
        self.g.step(3, "ARM")
        self.assertIsNone(self.g.deadline)
        self.assertFalse(self.g.armed)
        self.assertTrue(self.g.fault)

    def test_clear_fault_requires_explicit_recovery(self):
        self.ready()
        self.g.step(1, "FAULT")
        self.g.step(2, "CLEAR_FAULT")
        self.assertFalse(self.g.fault)
        self.assertEqual(self.g.step(3, "FORWARD"), "STOP")
        self.g.step(4, "RENEW")
        self.assertEqual(self.g.step(5, "FORWARD"), "STOP")
        self.g.step(6, "ARM")
        self.assertEqual(self.g.step(7, "FORWARD"), "FORWARD")

    def test_reconnect_does_not_clear_fault(self):
        self.ready()
        for t, event in enumerate(("FAULT", "DISCONNECT", "CONNECT", "RENEW", "ARM"), 1):
            self.assertEqual(self.g.step(t, event), "STOP")
        self.assertTrue(self.g.fault)
        self.assertEqual(self.g.step(6, "RIGHT"), "STOP")

    def test_clock_rollback_revokes_and_needs_recovery(self):
        self.ready(100)
        self.assertEqual(self.g.step(99, "FORWARD"), "STOP")
        self.assertFalse(self.g.armed)
        self.assertIsNone(self.g.deadline)
        self.g.step(99, "RENEW")
        self.assertIsNone(self.g.deadline)
        self.assertEqual(self.g.step(100, "FORWARD"), "STOP")
        self.g.step(101, "ARM")
        self.assertFalse(self.g.armed)
        self.g.step(102, "RENEW")
        self.assertEqual(self.g.step(103, "FORWARD"), "STOP")
        self.g.step(104, "ARM")
        self.assertEqual(self.g.step(105, "FORWARD"), "FORWARD")

    def test_rollback_fault_still_latches(self):
        self.ready(100)
        self.assertEqual(self.g.step(99, "FAULT"), "STOP")
        self.assertTrue(self.g.fault)
        self.g.step(100, "RENEW")
        self.assertIsNone(self.g.deadline)

    def test_rollback_disconnect_still_latches(self):
        self.ready(100)
        self.assertEqual(self.g.step(99, "DISCONNECT"), "STOP")
        self.assertFalse(self.g.connected)

    def test_equal_timestamp_allowed(self):
        self.ready(100)
        self.assertEqual(self.g.step(100, "FORWARD"), "FORWARD")

    def test_unknown_event_revokes_and_needs_recovery(self):
        self.ready()
        for event in ("JUMP", "", "forward"):
            with self.subTest(event=event):
                self.assertEqual(self.g.step(1, event), "STOP")
                self.assertFalse(self.g.armed)
                self.assertIsNone(self.g.deadline)
        self.g.step(2, "ARM")
        self.assertEqual(self.g.step(3, "LEFT"), "STOP")
        self.g.step(4, "RENEW")
        self.assertEqual(self.g.step(5, "LEFT"), "STOP")
        self.g.step(6, "ARM")
        self.assertEqual(self.g.step(7, "LEFT"), "LEFT")

    def test_nonmotion_events_always_stop(self):
        for event in ("CONNECT", "DISCONNECT", "RENEW", "ARM", "STOP", "FAULT", "CLEAR_FAULT"):
            with self.subTest(event=event):
                self.g = BodyGate()
                self.ready()
                self.assertEqual(self.g.step(1, event), "STOP")

    def test_large_time_jump_expires(self):
        self.ready()
        self.assertEqual(self.g.step(10**18, "FORWARD"), "STOP")
        self.assertFalse(self.g.armed)

    def test_malformed_arguments_fail_closed(self):
        for time, event in ((None, "FORWARD"), (True, "FORWARD"), (1, [])):
            with self.subTest(time=time, event=event):
                self.g = BodyGate()
                self.ready()
                self.assertEqual(self.g.step(time, event), "STOP")
                self.assertFalse(self.g.armed)
                self.assertIsNone(self.g.deadline)


if __name__ == "__main__":
    unittest.main()
