"""Stateless, first-matching-rule evaluation for task C."""
import json
from pathlib import Path

REQUIRED = {"connected", "armed", "lease_age_ms", "fault", "cmd"}
MOVEMENTS = {"FORWARD", "BACKWARD", "LEFT", "RIGHT"}


def decide(sample):
    if not REQUIRED.issubset(sample):
        output, reason = "STOP", "MISSING_FIELD"
    elif sample["cmd"] == "STOP":
        output, reason = "STOP", "STOP_COMMAND"
    elif sample["connected"] is False:
        output, reason = "STOP", "DISCONNECTED"
    elif sample["fault"] is True:
        output, reason = "STOP", "FAULT"
    elif sample["lease_age_ms"] >= 250:
        output, reason = "STOP", "STALE_LEASE"
    elif sample["armed"] is False:
        output, reason = "STOP", "DISARMED"
    elif sample["cmd"] not in MOVEMENTS:
        output, reason = "STOP", "UNKNOWN_COMMAND"
    else:
        output, reason = sample["cmd"], "OK"
    return {"id": sample["id"], "output": output, "reason": reason}


if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    samples = json.loads((root / "input_c.json").read_text(encoding="utf-8"))
    result = {"results": [decide(sample) for sample in samples]}
    serialized = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    (root / "result_c.json").write_text(serialized, encoding="utf-8")
    print(serialized, end="")
