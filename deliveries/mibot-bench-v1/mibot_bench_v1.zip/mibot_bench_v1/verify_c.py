import json
from pathlib import Path

root = Path(__file__).resolve().parent
result = json.loads((root / "result_c.json").read_text(encoding="utf-8"))
expected = [
    ("a", "FORWARD", "OK"), ("b", "STOP", "STALE_LEASE"),
    ("c", "STOP", "DISCONNECTED"), ("d", "STOP", "FAULT"),
    ("e", "STOP", "STALE_LEASE"), ("f", "STOP", "STOP_COMMAND"),
    ("g", "STOP", "DISARMED"), ("h", "STOP", "MISSING_FIELD"),
    ("i", "BACKWARD", "OK"), ("j", "STOP", "STOP_COMMAND"),
]
assert type(result) is dict and set(result) == {"results"}
assert type(result["results"]) is list and len(result["results"]) == 10
for item, values in zip(result["results"], expected):
    assert type(item) is dict and set(item) == {"id", "output", "reason"}
    assert (item["id"], item["output"], item["reason"]) == values
print("C JSON verification: 10/10 results match; schema and JSON parse PASS")
