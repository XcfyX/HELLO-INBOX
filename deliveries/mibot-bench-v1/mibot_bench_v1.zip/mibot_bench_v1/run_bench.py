"""Run local checks and preserve raw output and command metadata."""
import json
import platform
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
commands = [
    ([sys.executable, "-m", "unittest", "-v", "test_bodygate.py"], "test_bodygate.log"),
    ([sys.executable, "solve_c.py"], "run_c.log"),
    ([sys.executable, "verify_c.py"], "verify_c.log"),
]
records = []
for command, log_name in commands:
    result = subprocess.run(command, cwd=root, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, check=False)
    (root / log_name).write_bytes(result.stdout)
    records.append({"command": command, "cwd": str(root),
                    "exit_code": result.returncode, "raw_log": log_name})
    print("COMMAND:", " ".join(command))
    sys.stdout.flush()
    sys.stdout.buffer.write(result.stdout)
    sys.stdout.buffer.flush()
    print("EXIT_CODE:", result.returncode, flush=True)
(root / "execution.json").write_text(json.dumps({
    "python": platform.python_version(), "runs": records
}, indent=2) + "\n", encoding="utf-8")
raise SystemExit(any(record["exit_code"] != 0 for record in records))
